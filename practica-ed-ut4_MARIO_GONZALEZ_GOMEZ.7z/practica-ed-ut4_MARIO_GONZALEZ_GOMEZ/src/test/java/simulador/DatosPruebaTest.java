package simulador;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
/**
 * Esta clase prueba los m�todos p�blicos de DatosPrueba
 * @author Mario
 *
 */
public class DatosPruebaTest {
	DatosPrueba dptest = new DatosPrueba();

	/**
	 * Este test vigila que el double[] salida de generadorPrecios tenga el mismo
	 * length que el n�mero de Producto contenido en un objeto Tienda
	 */
	@Test
	public void generadorPreciosOk() {
		Assertions.assertTrue(dptest.generadorPrecios().length == 20);
	}

	/**
	 * Se comprueba que el m�todo generadorPrecios no devuelva un valor null
	 */
	@Test
	public void generadorPreciosNotNull() {
		Assertions.assertFalse(dptest.generadorPrecios() == null);
	}

	/**
	 * Este test vigila que el double[] salida de generadorCostes tenga el mismo
	 * length que el n�mero de Producto contenido en un objeto Tienda
	 */
	@Test
	public void generadorCostesOk() {
		Assertions.assertTrue(dptest.generadorCostes().length == 20);
	}

	/**
	 * Se comprueba que el m�todo generadorCostes no devuelva un valor null
	 */
	@Test
	public void generadorCostesNotNull() {
		Assertions.assertFalse(dptest.generadorCostes() == null);
	}
}
