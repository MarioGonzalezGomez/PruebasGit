package service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import entity.Producto;
import entity.Tienda;

/**
 * Esta clase prueba los m�todos p�blicos de Servicios
 * 
 * @author Mario
 *
 */
public class ServicioTest {
	Servicio servtest = new Servicio();
	Tienda tiendaTest = new Tienda();
	Producto prodTest1 = new Producto(100, 50);
	Producto prodTest3 = new Producto(19, 10);
	Producto prodTest2 = new Producto(10, 10);

	Producto[] productos = { prodTest1, prodTest2, prodTest3 };

	/**
	 * Este test vigila que el double[] salida de margenBeneficio tenga el mismo
	 * length que el n�mero de Producto contenido en un objeto Tienda
	 */
	@Test
	public void margenBeneficioSalidaOk() {
		tiendaTest.setProductos(productos);
		Assertions.assertTrue(servtest.margenBeneficio(tiendaTest).length == productos.length);
	}

	/**
	 * Este test vigila que el funcionamiento de margenBeneficio sea correcto,
	 * introduciendo unos datos de testeo y comparando el resultado esperado con la
	 * salida
	 */
	@Test
	public void margenBeneficioCalculoOk() {
		tiendaTest.setProductos(productos);
		Assertions.assertEquals(50.0, servtest.margenBeneficio(tiendaTest)[0]);
	}

	/**
	 * Este test vigila que el funcionamiento de mayorMargenBeneficio sea correcto,
	 * introduciendo unos datos de testeo y comparando el resultado esperado con la
	 * salida
	 */
	@Test
	public void mayorMargenBeneficioCalculoOk() {
		tiendaTest.setProductos(productos);
		servtest.margenBeneficio(tiendaTest);
		servtest.mayorMargenBeneficio(tiendaTest);
		Assertions.assertEquals(50.0, tiendaTest.getMaxMargen());
	}

	/**
	 * Este test vigila que el funcionamiento de menorMargenBeneficio sea correcto,
	 * introduciendo unos datos de testeo y comparando el resultado esperado con la
	 * salida
	 */
	@Test
	public void menorMargenBeneficioCalculoOk() {
		tiendaTest.setProductos(productos);
		servtest.margenBeneficio(tiendaTest);
		servtest.menorMargenBeneficio(tiendaTest);
		Assertions.assertEquals(0.0, tiendaTest.getMinMargen());
	}

	/**
	 * Este test vigila que el funcionamiento de nuevoPrecio sea correcto,
	 * introduciendo unos datos de testeo. Se testea con el Producto 3, que tiene
	 * menos de un 10% de margen de beneficio, esperando que el m�todo devuelva un
	 * valor distinto de 0 en su posici�n
	 */
	@Test
	public void nuevoPrecioCalculoOk() {
		tiendaTest.setProductos(productos);
		servtest.margenBeneficio(tiendaTest);
		servtest.nuevoPrecioMargenMenorDiez(tiendaTest);
		Assertions.assertNotEquals(0.0, tiendaTest.getProductos()[2].getPrecio());
	}

	/**
	 * Este test vigila que el funcionamiento de beneficioTotal sea correcto,
	 * introduciendo unos datos de testeo y comparando el resultado esperado con la
	 * salida
	 */
	@Test
	public void beneficioTotalCalculoOk() {
		tiendaTest.setProductos(productos);
		Assertions.assertEquals(59.0, servtest.beneficioTotal(tiendaTest));
	}

	/**
	 * Este test vigila que el double[] salida de crearArrayPrecios tenga el mismo
	 * length que el n�mero de Producto contenido en un objeto Tienda
	 */
	@Test
	public void crearArrayPreciosOk() {
		tiendaTest.setProductos(productos);
		Assertions.assertTrue(servtest.crearArrayPrecios(tiendaTest).length == productos.length);
	}

	/**
	 * Se comprueba que el m�todo crearArrayPrecios no devuelva un valor null
	 */
	@Test
	public void crearArrayPreciosNotNull() {
		tiendaTest.setProductos(productos);
		Assertions.assertFalse(servtest.crearArrayPrecios(tiendaTest) == null);
	}

	/**
	 * Este test vigila que el double[] salida de crearArrayCostes tenga el mismo
	 * length que el n�mero de Producto contenido en un objeto Tienda
	 */
	@Test
	public void crearArrayCostesOk() {
		tiendaTest.setProductos(productos);
		Assertions.assertTrue(servtest.crearArrayCostes(tiendaTest).length == productos.length);
	}

	/**
	 * Se comprueba que el m�todo crearArrayCostes no devuelva un valor null
	 */
	@Test
	public void crearArrayCostesNotNull() {
		tiendaTest.setProductos(productos);
		Assertions.assertFalse(servtest.crearArrayCostes(tiendaTest) == null);
	}
}
