package service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
/**
 * Esta clase prueba los m�todos p�blicos de TiendaBuilder
 * @author Mario
 *
 */
public class TiendaBuilderTest {
	TiendaBuilder tiendaTest = new TiendaBuilder();

	/**
	 * Se comprueba que el m�todo generaTienda no devuelva un valor null
	 */
	@Test
	public void generaTiendaNotNull() {
		Assertions.assertFalse(tiendaTest.generaTienda() == null);
	}

	/**
	 * Este test vigila que el Producto[] salida de generaTienda tenga el mismo length
	 * que la constante definida como NUM_PRODUCTOS
	 */
	@Test
	public void generaTiendaOk() {
		Assertions.assertTrue(tiendaTest.generaTienda().getProductos().length == 20);
	}
}
