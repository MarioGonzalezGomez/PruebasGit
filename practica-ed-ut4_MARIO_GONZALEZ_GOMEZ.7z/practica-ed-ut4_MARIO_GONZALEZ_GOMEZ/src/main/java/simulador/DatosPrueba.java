package simulador;

import java.math.BigDecimal;
import java.math.RoundingMode;

import entity.Tienda;

/**
 * En esta clase se almacenan los m�todos para la generaci�n de arrays de
 * precios y costes con datos randomizados
 * 
 * @author Mario
 *
 */
public class DatosPrueba {

	static int maxPrecio = 2000;
	static int maxCoste = 1000;

	// Genera precio random entre 0 y 2000
	/**
	 * Este m�todo genera un array con la capacidad definida en NUM_PRODUCTOS con
	 * precios aleatorios desde 0 hasta maxPrecio
	 * 
	 * @return arrayPrecios double[]
	 */
	public double[] generadorPrecios() {
		double[] arrayPrecios = new double[Tienda.getNumProductos()];
		for (int i = 0; i < arrayPrecios.length; i++) {
			arrayPrecios[i] = BigDecimal.valueOf(Math.random() * maxPrecio).setScale(2, RoundingMode.HALF_UP)
					.doubleValue();

		}
		return arrayPrecios;
	}

	// Genera coste random entre 0 y 1000
	/**
	 * Este m�todo genera un array con la capacidad definida en NUM_PRODUCTOS con
	 * costes aleatorios desde 0 hasta maxCoste
	 * 
	 * @return arrayCoste double[]
	 */
	public double[] generadorCostes() {
		double[] arrayCoste = new double[Tienda.getNumProductos()];
		for (int i = 0; i < arrayCoste.length; i++) {
			arrayCoste[i] = BigDecimal.valueOf(Math.random() * maxCoste).setScale(2, RoundingMode.HALF_UP)
					.doubleValue();
		}
		return arrayCoste;
	}

}
