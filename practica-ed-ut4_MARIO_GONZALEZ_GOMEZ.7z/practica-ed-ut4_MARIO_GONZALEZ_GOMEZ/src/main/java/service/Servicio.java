package service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import entity.Tienda;
import simulador.*;

/**
 * En esta clase se almacenan los m�todos utilizados en la clase Principal
 * 
 * @author Mario
 *
 */
public class Servicio {

	DatosPrueba random = new DatosPrueba();
	Tienda tienda = new Tienda();

	// int idMaxMargen = 0;
	// int idMinMargen = 0;
	// double maxMargen = 0, minMargen = 0;

	// vector con los rendimientos generadas
	// double[] arrayPrecios = new double[20];
	// double[] arrayCoste = new double[20];
	// Double[] arrayMargenes = margenBeneficio();
/**
 * Contructor por defecto para la clase Servicio
 */
	public Servicio() {

	}

	// Operaciones
	// 1. Calcula Margen de beneficio
	/**
	 * Este m�todo recibe un objeto Tienda como par�metro, calcula y retorna en un
	 * array double[] los m�rgenes de beneficio tomando los datos de los objetos
	 * Producto introducidos en la Tienda
	 * 
	 * @param tienda Tienda
	 * @return arrayMargenes double[]
	 */
	public double[] margenBeneficio(Tienda tienda) {

		double[] arrayMargenes = new double[tienda.getProductos().length];

		for (int i = 0; i < tienda.getProductos().length; i++) {
			arrayMargenes[i] = BigDecimal
					.valueOf(((tienda.getProductos()[i].getPrecio() - tienda.getProductos()[i].getCostes())
							/ tienda.getProductos()[i].getPrecio()) * 100)
					.setScale(2, RoundingMode.HALF_UP).doubleValue();
		}
		tienda.setMargenBeneficio(arrayMargenes);
		return arrayMargenes;
	}

	// creo otro array para que me almacene la salida del metodo margen beneficio
	// 2. Obtener el id del producto con mayor margen de beneficio
	/**
	 * Este m�todo recibe un objeto Tienda como par�metro y compara los datos del
	 * double [] margenBeneficio para obtener el mayor. Una vez obtenido, carga su
	 * margen en una variable maxMargen y la id del Producto en una variable int
	 * productoMaxMargen
	 * 
	 * @param tienda Tienda
	 */
	public void mayorMargenBeneficio(Tienda tienda) {
		// double postEval = Double.MIN_VALUE;
		double aux = 0;
		for (int i = 0; i < tienda.getMargenBeneficio().length; i++) {
			double margenMayorTemporal = tienda.getMargenBeneficio()[i];
			if (margenMayorTemporal > aux) {
				aux = margenMayorTemporal;
				tienda.setMaxMargen(margenMayorTemporal);
				tienda.setProductoMaxMargen(i + 1);
			}
		}
	}

	// 3. Obtener el id del producto con menor margen de beneficio
	/**
	 * Este m�todo recibe un objeto Tienda como par�metro y compara los datos del
	 * double [] margenBeneficio para obtener el menor. Una vez obtenido, carga su
	 * margen en una variable minMargen y la id del Producto en una variable int
	 * productoMinMargen
	 * 
	 * @param tienda Tienda
	 */
	public void menorMargenBeneficio(Tienda tienda) {
		double aux = 100000;
		// double postEval = Double.MAX_VALUE;

		for (int i = 0; i < tienda.getMargenBeneficio().length; i++) {
			double margenMenorTemporal = tienda.getMargenBeneficio()[i];
			if (margenMenorTemporal < aux) {
				aux = margenMenorTemporal;
				tienda.setMinMargen(margenMenorTemporal);
				tienda.setProductoMinMargen(i + 1);
			}
		}
	}

	// 4. Calcular el precio del producto para todos aquellos productos que no
	// tengan al menos un margen del 10%
	/**
	 * Este m�todo recibe un objeto Tienda como par�metro y recorre su array de
	 * margenBeneficio. Si encuentra un valor menor a 10, recalcula el precio del
	 * Producto y lo introduce en un nuevo array
	 * 
	 * @param tienda Tienda
	 * @return arrayNuevoPrecio double[]
	 */
	public double[] nuevoPrecioMargenMenorDiez(Tienda tienda) {
		// declaro la variable para el 10% evitando magic numbers
		int porcentajeBeneficioPequenio = 10;
		double fraccionPorcentaje = 0.1;
		double[] arrayNuevoPrecio = new double[tienda.getProductos().length];
		for (int i = 0; i < tienda.getMargenBeneficio().length; i++) {
			if (tienda.getMargenBeneficio()[i] < porcentajeBeneficioPequenio) {
				arrayNuevoPrecio[i] = BigDecimal
						.valueOf((tienda.getProductos()[i].getCostes() / (1 - fraccionPorcentaje)))
						.setScale(2, RoundingMode.HALF_UP).doubleValue();
			}
		}
		tienda.setPreciosActualizados(arrayNuevoPrecio);
		return arrayNuevoPrecio;
	}

	// 5. Beneficio total
	/**
	 * Este m�todo recibe un objeto Tienda como par�metro y suma sus beneficios
	 * (precio- costes) de todos los Producto que contenga, devolviendo el resultado
	 * en un double
	 * 
	 * @param tienda Tienda
	 * @return beneficio double
	 */
	public double beneficioTotal(Tienda tienda) {
		double beneficio = tienda.getBeneficio();
		for (int i = 0; i < tienda.getProductos().length; i++) {
			beneficio = BigDecimal
					.valueOf(beneficio + (tienda.getProductos()[i].getPrecio() - tienda.getProductos()[i].getCostes()))
					.setScale(2, RoundingMode.HALF_UP).doubleValue();
		}
		tienda.setBeneficio(beneficio);
		return beneficio;
	}

	/**
	 * Este m�todo recibe un objeto Tienda como par�metro y recorre los precios de
	 * los objeto Producto que contiene para crear un array, pensado para la
	 * posterior impresion de los datos con el m�todo Arrays.toString()
	 * 
	 * @param tienda Tienda
	 * @return precios double[]
	 */
	public double[] crearArrayPrecios(Tienda tienda) {
		double[] precios = new double[tienda.getProductos().length];
		for (int i = 0; i < tienda.getProductos().length; i++) {
			precios[i] = tienda.getProductos()[i].getPrecio();

		}
		return precios;

	}

	/**
	 * Este m�todo recibe un objeto Tienda como par�metro y recorre los costes de
	 * los objeto Producto que contiene para crear un array, pensado para la
	 * posterior impresion de los datos con el m�todo Arrays.toString()
	 * 
	 * @param tienda Tienda
	 * @return costes double[]
	 */
	public double[] crearArrayCostes(Tienda tienda) {
		double[] costes = new double[tienda.getProductos().length];
		for (int i = 0; i < tienda.getProductos().length; i++) {
			costes[i] = tienda.getProductos()[i].getCostes();

		}
		return costes;

	}

}
