package entity;
/**
 * En esta clase se almacenan los datos getters y setters relacionados con Producto
 * @author Mario
 *
 */
public class Producto {

	static int idproducto = 1;
	private double precio;
	private double costes;
/**
 * Constructor por defecto con valores iniciados a 0. El idproducto se incrementar� con cada llamada al m�todo
 */
	public Producto() {
		precio = 0;
		costes = 0;
		idproducto++;
	}
/**
 * Contructor con precio y coste como par�metros de entrada.El idproducto se incrementar� con cada llamada al m�todo
 * @param precio double
 * @param coste double
 */
	public Producto(double precio, double coste) {
		this.precio = precio;
		this.costes = coste;
		idproducto++;
	}
/**
 * Getter de la variable privada precio
 * @return double precio
 */
	public double getPrecio() {
		return precio;
	}
/**
 * Setter que carga un valor double introducido por par�metro en la variable precio
 * @param precio double
 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	/**
	 * Getter de la variable privada costes
	 * @return double costes
	 */
	public double getCostes() {
		return costes;
	}

	/**
	 * Setter que carga un valor double introducido por par�metro en la variable costes
	 * @param coste double
	 */
	public void setCostes(double coste) {
		this.costes = coste;
	}

}
