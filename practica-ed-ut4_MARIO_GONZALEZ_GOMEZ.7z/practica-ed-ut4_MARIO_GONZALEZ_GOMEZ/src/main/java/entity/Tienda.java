package entity;

/**
 * En esta clase se almacenan los datos getters y setters relacionados con
 * Tienda
 * 
 * @author Mario
 *
 */
public class Tienda {
	private final static int NUM_PRODUCTOS = 20;
	private Producto[] productos;
	private double[] margenBeneficio;
	private double[] preciosActualizados;
	private double beneficio;
	private double maxMargen;
	private int productoMaxMargen;
	private double minMargen;
	private int productoMinMargen;

	/**
	 * Constructor por defecto con atributos productos, margenBeneficio, beneficio,
	 * maxMArgen, productoMaxMargen,minMargen, productoMinMargen y
	 * preciosActualizados.
	 */
	public Tienda() {
		productos = new Producto[NUM_PRODUCTOS];
		margenBeneficio = new double[NUM_PRODUCTOS];
		beneficio = 0;
		maxMargen = 0;
		productoMaxMargen = 0;
		minMargen = 0;
		productoMinMargen = 0;
		preciosActualizados = new double[NUM_PRODUCTOS];
	}

	/**
	 * Getter de la variable privada productos
	 * 
	 * @return productos Producto[]
	 */
	public Producto[] getProductos() {
		return productos;
	}

	/**
	 * Setter que carga un valor Producto[] introducido por par�metro en la variable
	 * productos
	 * 
	 * @param productos Producto[]
	 */
	public void setProductos(Producto[] productos) {
		this.productos = productos;
	}

	/**
	 * Getter de la variable privada beneficio
	 * 
	 * @return double beneficio
	 */
	public double getBeneficio() {
		return beneficio;
	}

	/**
	 * Setter que carga un valor double introducido por par�metro en la variable
	 * beneficio
	 * 
	 * @param beneficio double
	 */
	public void setBeneficio(double beneficio) {
		this.beneficio = beneficio;
	}

	/**
	 * Getter de la constante NUM_PRODUCTOS
	 * 
	 * @return NUM_PRODUCTOS int 
	 */
	public static int getNumProductos() {
		return NUM_PRODUCTOS;
	}

	/**
	 * Getter de la variable privada margenBeneficio
	 * 
	 * @return beneficio double[]
	 */
	public double[] getMargenBeneficio() {
		return margenBeneficio;
	}

	/**
	 * Setter que carga un valor double [] introducido por par�metro en la variable
	 * margenBeneficio
	 * 
	 * @param margenBeneficio double[] 
	 */
	public void setMargenBeneficio(double[] margenBeneficio) {
		this.margenBeneficio = margenBeneficio;
	}

	/**
	 * Getter de la variable privada preciosActualizados
	 * 
	 * @return preciosActualizados double[]
	 */
	public double[] getPreciosActualizados() {
		return preciosActualizados;
	}

	/**
	 * Setter que carga un valor double [] introducido por par�metro en la variable
	 * preciosActualizados
	 * 
	 * @param preciosActualizados double[]
	 */
	public void setPreciosActualizados(double[] preciosActualizados) {
		this.preciosActualizados = preciosActualizados;
	}

	/**
	 * Getter de la variable privada maxMargen
	 * 
	 * @return double maxMargen
	 */
	public double getMaxMargen() {
		return maxMargen;
	}

	/**
	 * Setter que carga un valor double introducido por par�metro en la variable
	 * MaxMargen
	 * 
	 * @param productoMaxMargen double
	 */
	public void setMaxMargen(double productoMaxMargen) {
		this.maxMargen = productoMaxMargen;
	}

	/**
	 * Getter de la variable privada minMargen
	 * 
	 * @return double minMargen
	 */
	public double getMinMargen() {
		return minMargen;
	}

	/**
	 * Setter que carga un valor double introducido por par�metro en la variable
	 * MinMargen
	 * 
	 * @param productoMinMargen double 
	 */
	public void setMinMargen(double productoMinMargen) {
		this.minMargen = productoMinMargen;
	}

	/**
	 * Getter de la variable privada productoMaxMargen
	 * 
	 * @return double productoMaxMargen
	 */
	public int getProductoMaxMargen() {
		return productoMaxMargen;
	}

	/**
	 * Setter que carga un valor int introducido por par�metro en la variable
	 * productoMaxMargen
	 * 
	 * @param productoMaxMargen int
	 */
	public void setProductoMaxMargen(int productoMaxMargen) {
		this.productoMaxMargen = productoMaxMargen;
	}

	/**
	 * Getter de la variable privada productoMinMargen
	 * 
	 * @return productoMinMargen int
	 */
	public int getProductoMinMargen() {
		return productoMinMargen;
	}

	/**
	 * Getter de la variable privada productoMinMargen
	 * 
	 * @param productoMinMargen int
	 */
	public void setProductoMinMargen(int productoMinMargen) {
		this.productoMinMargen = productoMinMargen;
	}

}